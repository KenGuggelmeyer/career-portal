<?php
/*
Plugin Name: Bullhorn-oscp
Plugin URI: https://github.com/bullhorn/career-portal
Description: A really simple lightweight installer for Career Portal inside of Wordpress.
Version: 3.4.3-custom
Author: Antwerp Software Solutions
Author URI: http://antss.be
License: MIT
*/

define("OSCP_APP_JSON_PATH", plugin_dir_path(__FILE__) . "app.json");
define('OSCP_PLUGIN_VERSION', '3.4.2 - Custom');


class OSCP_Config
{
    private $oscp_options;

    public function __construct()
    {
        add_action('admin_menu', array($this, 'oscp_add_plugin_page'));
        add_action('admin_init', array($this, 'oscp_config_page_init'));
    }

    public function oscp_add_plugin_page()
    {
        add_plugins_page(
            'Career Portal',    // page_title
            'Career Portal',    // menu_title
            'manage_options',   // capability
            'bullhorn-oscp',    // menu_slug
            array($this, 'oscp_create_admin_page')
        );
    }

    public function oscp_create_admin_page()
    {
        $this->oscp_options = get_option('oscp_config_data'); ?>

        <link href="<?php echo plugins_url('config.css', __FILE__); ?>" rel="stylesheet" />

        <div class="wrap" id="oscp-container">
            <?php
            settings_errors();
            if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
                oscp_save_file(false);
            }
            ?>

            <style>
                /* Flexbox Grid */
                .container,
                .container-fluid {
                    margin-right: auto;
                    margin-left: auto
                }

                .container-fluid {
                    padding-right: 2rem;
                    padding-left: 2rem
                }

                .row {
                    box-sizing: border-box;
                    display: -webkit-box;
                    display: -ms-flexbox;
                    display: flex;
                    -webkit-box-flex: 0;
                    -ms-flex: 0 1 auto;
                    flex: 0 1 auto;
                    -webkit-box-orient: horizontal;
                    -webkit-box-direction: normal;
                    -ms-flex-direction: row;
                    flex-direction: row;
                    -ms-flex-wrap: wrap;
                    flex-wrap: wrap;
                    margin-right: -.5rem;
                    margin-left: -.5rem
                }

                .row.reverse {
                    -webkit-box-orient: horizontal;
                    -webkit-box-direction: reverse;
                    -ms-flex-direction: row-reverse;
                    flex-direction: row-reverse
                }

                .col.reverse {
                    -webkit-box-orient: vertical;
                    -webkit-box-direction: reverse;
                    -ms-flex-direction: column-reverse;
                    flex-direction: column-reverse
                }

                .col-xs,
                .col-xs-1,
                .col-xs-10,
                .col-xs-11,
                .col-xs-12,
                .col-xs-2,
                .col-xs-3,
                .col-xs-4,
                .col-xs-5,
                .col-xs-6,
                .col-xs-7,
                .col-xs-8,
                .col-xs-9,
                .col-xs-offset-0,
                .col-xs-offset-1,
                .col-xs-offset-10,
                .col-xs-offset-11,
                .col-xs-offset-12,
                .col-xs-offset-2,
                .col-xs-offset-3,
                .col-xs-offset-4,
                .col-xs-offset-5,
                .col-xs-offset-6,
                .col-xs-offset-7,
                .col-xs-offset-8,
                .col-xs-offset-9 {
                    box-sizing: border-box;
                    -webkit-box-flex: 0;
                    -ms-flex: 0 0 auto;
                    flex: 0 0 auto;
                    padding-right: .5rem;
                    padding-left: .5rem
                }

                .col-xs {
                    -webkit-box-flex: 1;
                    -ms-flex-positive: 1;
                    flex-grow: 1;
                    -ms-flex-preferred-size: 0;
                    flex-basis: 0;
                    max-width: 100%
                }

                .col-xs-1 {
                    -ms-flex-preferred-size: 8.33333333%;
                    flex-basis: 8.33333333%;
                    max-width: 8.33333333%
                }

                .col-xs-2 {
                    -ms-flex-preferred-size: 16.66666667%;
                    flex-basis: 16.66666667%;
                    max-width: 16.66666667%
                }

                .col-xs-3 {
                    -ms-flex-preferred-size: 25%;
                    flex-basis: 25%;
                    max-width: 25%
                }

                .col-xs-4 {
                    -ms-flex-preferred-size: 33.33333333%;
                    flex-basis: 33.33333333%;
                    max-width: 33.33333333%
                }

                .col-xs-5 {
                    -ms-flex-preferred-size: 41.66666667%;
                    flex-basis: 41.66666667%;
                    max-width: 41.66666667%
                }

                .col-xs-6 {
                    -ms-flex-preferred-size: 50%;
                    flex-basis: 50%;
                    max-width: 50%
                }

                .col-xs-7 {
                    -ms-flex-preferred-size: 58.33333333%;
                    flex-basis: 58.33333333%;
                    max-width: 58.33333333%
                }

                .col-xs-8 {
                    -ms-flex-preferred-size: 66.66666667%;
                    flex-basis: 66.66666667%;
                    max-width: 66.66666667%
                }

                .col-xs-9 {
                    -ms-flex-preferred-size: 75%;
                    flex-basis: 75%;
                    max-width: 75%
                }

                .col-xs-10 {
                    -ms-flex-preferred-size: 83.33333333%;
                    flex-basis: 83.33333333%;
                    max-width: 83.33333333%
                }

                .col-xs-11 {
                    -ms-flex-preferred-size: 91.66666667%;
                    flex-basis: 91.66666667%;
                    max-width: 91.66666667%
                }

                .col-xs-12 {
                    -ms-flex-preferred-size: 100%;
                    flex-basis: 100%;
                    max-width: 100%
                }

                .col-xs-offset-0 {
                    margin-left: 0
                }

                .col-xs-offset-1 {
                    margin-left: 8.33333333%
                }

                .col-xs-offset-2 {
                    margin-left: 16.66666667%
                }

                .col-xs-offset-3 {
                    margin-left: 25%
                }

                .col-xs-offset-4 {
                    margin-left: 33.33333333%
                }

                .col-xs-offset-5 {
                    margin-left: 41.66666667%
                }

                .col-xs-offset-6 {
                    margin-left: 50%
                }

                .col-xs-offset-7 {
                    margin-left: 58.33333333%
                }

                .col-xs-offset-8 {
                    margin-left: 66.66666667%
                }

                .col-xs-offset-9 {
                    margin-left: 75%
                }

                .col-xs-offset-10 {
                    margin-left: 83.33333333%
                }

                .col-xs-offset-11 {
                    margin-left: 91.66666667%
                }

                .start-xs {
                    -webkit-box-pack: start;
                    -ms-flex-pack: start;
                    justify-content: flex-start;
                    text-align: start
                }

                .center-xs {
                    -webkit-box-pack: center;
                    -ms-flex-pack: center;
                    justify-content: center;
                    text-align: center
                }

                .end-xs {
                    -webkit-box-pack: end;
                    -ms-flex-pack: end;
                    justify-content: flex-end;
                    text-align: end
                }

                .top-xs {
                    -webkit-box-align: start;
                    -ms-flex-align: start;
                    align-items: flex-start
                }

                .middle-xs {
                    -webkit-box-align: center;
                    -ms-flex-align: center;
                    align-items: center
                }

                .bottom-xs {
                    -webkit-box-align: end;
                    -ms-flex-align: end;
                    align-items: flex-end
                }

                .around-xs {
                    -ms-flex-pack: distribute;
                    justify-content: space-around
                }

                .between-xs {
                    -webkit-box-pack: justify;
                    -ms-flex-pack: justify;
                    justify-content: space-between
                }

                .first-xs {
                    -webkit-box-ordinal-group: 0;
                    -ms-flex-order: -1;
                    order: -1
                }

                .last-xs {
                    -webkit-box-ordinal-group: 2;
                    -ms-flex-order: 1;
                    order: 1
                }

                @media only screen and (min-width:48em) {
                    .container {
                        width: 49rem
                    }

                    .col-sm,
                    .col-sm-1,
                    .col-sm-10,
                    .col-sm-11,
                    .col-sm-12,
                    .col-sm-2,
                    .col-sm-3,
                    .col-sm-4,
                    .col-sm-5,
                    .col-sm-6,
                    .col-sm-7,
                    .col-sm-8,
                    .col-sm-9,
                    .col-sm-offset-0,
                    .col-sm-offset-1,
                    .col-sm-offset-10,
                    .col-sm-offset-11,
                    .col-sm-offset-12,
                    .col-sm-offset-2,
                    .col-sm-offset-3,
                    .col-sm-offset-4,
                    .col-sm-offset-5,
                    .col-sm-offset-6,
                    .col-sm-offset-7,
                    .col-sm-offset-8,
                    .col-sm-offset-9 {
                        box-sizing: border-box;
                        -webkit-box-flex: 0;
                        -ms-flex: 0 0 auto;
                        flex: 0 0 auto;
                        padding-right: .5rem;
                        padding-left: .5rem
                    }

                    .col-sm {
                        -webkit-box-flex: 1;
                        -ms-flex-positive: 1;
                        flex-grow: 1;
                        -ms-flex-preferred-size: 0;
                        flex-basis: 0;
                        max-width: 100%
                    }

                    .col-sm-1 {
                        -ms-flex-preferred-size: 8.33333333%;
                        flex-basis: 8.33333333%;
                        max-width: 8.33333333%
                    }

                    .col-sm-2 {
                        -ms-flex-preferred-size: 16.66666667%;
                        flex-basis: 16.66666667%;
                        max-width: 16.66666667%
                    }

                    .col-sm-3 {
                        -ms-flex-preferred-size: 25%;
                        flex-basis: 25%;
                        max-width: 25%
                    }

                    .col-sm-4 {
                        -ms-flex-preferred-size: 33.33333333%;
                        flex-basis: 33.33333333%;
                        max-width: 33.33333333%
                    }

                    .col-sm-5 {
                        -ms-flex-preferred-size: 41.66666667%;
                        flex-basis: 41.66666667%;
                        max-width: 41.66666667%
                    }

                    .col-sm-6 {
                        -ms-flex-preferred-size: 50%;
                        flex-basis: 50%;
                        max-width: 50%
                    }

                    .col-sm-7 {
                        -ms-flex-preferred-size: 58.33333333%;
                        flex-basis: 58.33333333%;
                        max-width: 58.33333333%
                    }

                    .col-sm-8 {
                        -ms-flex-preferred-size: 66.66666667%;
                        flex-basis: 66.66666667%;
                        max-width: 66.66666667%
                    }

                    .col-sm-9 {
                        -ms-flex-preferred-size: 75%;
                        flex-basis: 75%;
                        max-width: 75%
                    }

                    .col-sm-10 {
                        -ms-flex-preferred-size: 83.33333333%;
                        flex-basis: 83.33333333%;
                        max-width: 83.33333333%
                    }

                    .col-sm-11 {
                        -ms-flex-preferred-size: 91.66666667%;
                        flex-basis: 91.66666667%;
                        max-width: 91.66666667%
                    }

                    .col-sm-12 {
                        -ms-flex-preferred-size: 100%;
                        flex-basis: 100%;
                        max-width: 100%
                    }

                    .col-sm-offset-0 {
                        margin-left: 0
                    }

                    .col-sm-offset-1 {
                        margin-left: 8.33333333%
                    }

                    .col-sm-offset-2 {
                        margin-left: 16.66666667%
                    }

                    .col-sm-offset-3 {
                        margin-left: 25%
                    }

                    .col-sm-offset-4 {
                        margin-left: 33.33333333%
                    }

                    .col-sm-offset-5 {
                        margin-left: 41.66666667%
                    }

                    .col-sm-offset-6 {
                        margin-left: 50%
                    }

                    .col-sm-offset-7 {
                        margin-left: 58.33333333%
                    }

                    .col-sm-offset-8 {
                        margin-left: 66.66666667%
                    }

                    .col-sm-offset-9 {
                        margin-left: 75%
                    }

                    .col-sm-offset-10 {
                        margin-left: 83.33333333%
                    }

                    .col-sm-offset-11 {
                        margin-left: 91.66666667%
                    }

                    .start-sm {
                        -webkit-box-pack: start;
                        -ms-flex-pack: start;
                        justify-content: flex-start;
                        text-align: start
                    }

                    .center-sm {
                        -webkit-box-pack: center;
                        -ms-flex-pack: center;
                        justify-content: center;
                        text-align: center
                    }

                    .end-sm {
                        -webkit-box-pack: end;
                        -ms-flex-pack: end;
                        justify-content: flex-end;
                        text-align: end
                    }

                    .top-sm {
                        -webkit-box-align: start;
                        -ms-flex-align: start;
                        align-items: flex-start
                    }

                    .middle-sm {
                        -webkit-box-align: center;
                        -ms-flex-align: center;
                        align-items: center
                    }

                    .bottom-sm {
                        -webkit-box-align: end;
                        -ms-flex-align: end;
                        align-items: flex-end
                    }

                    .around-sm {
                        -ms-flex-pack: distribute;
                        justify-content: space-around
                    }

                    .between-sm {
                        -webkit-box-pack: justify;
                        -ms-flex-pack: justify;
                        justify-content: space-between
                    }

                    .first-sm {
                        -webkit-box-ordinal-group: 0;
                        -ms-flex-order: -1;
                        order: -1
                    }

                    .last-sm {
                        -webkit-box-ordinal-group: 2;
                        -ms-flex-order: 1;
                        order: 1
                    }
                }

                @media only screen and (min-width:64em) {
                    .container {
                        width: 65rem
                    }

                    .col-md,
                    .col-md-1,
                    .col-md-10,
                    .col-md-11,
                    .col-md-12,
                    .col-md-2,
                    .col-md-3,
                    .col-md-4,
                    .col-md-5,
                    .col-md-6,
                    .col-md-7,
                    .col-md-8,
                    .col-md-9,
                    .col-md-offset-0,
                    .col-md-offset-1,
                    .col-md-offset-10,
                    .col-md-offset-11,
                    .col-md-offset-12,
                    .col-md-offset-2,
                    .col-md-offset-3,
                    .col-md-offset-4,
                    .col-md-offset-5,
                    .col-md-offset-6,
                    .col-md-offset-7,
                    .col-md-offset-8,
                    .col-md-offset-9 {
                        box-sizing: border-box;
                        -webkit-box-flex: 0;
                        -ms-flex: 0 0 auto;
                        flex: 0 0 auto;
                        padding-right: .5rem;
                        padding-left: .5rem
                    }

                    .col-md {
                        -webkit-box-flex: 1;
                        -ms-flex-positive: 1;
                        flex-grow: 1;
                        -ms-flex-preferred-size: 0;
                        flex-basis: 0;
                        max-width: 100%
                    }

                    .col-md-1 {
                        -ms-flex-preferred-size: 8.33333333%;
                        flex-basis: 8.33333333%;
                        max-width: 8.33333333%
                    }

                    .col-md-2 {
                        -ms-flex-preferred-size: 16.66666667%;
                        flex-basis: 16.66666667%;
                        max-width: 16.66666667%
                    }

                    .col-md-3 {
                        -ms-flex-preferred-size: 25%;
                        flex-basis: 25%;
                        max-width: 25%
                    }

                    .col-md-4 {
                        -ms-flex-preferred-size: 33.33333333%;
                        flex-basis: 33.33333333%;
                        max-width: 33.33333333%
                    }

                    .col-md-5 {
                        -ms-flex-preferred-size: 41.66666667%;
                        flex-basis: 41.66666667%;
                        max-width: 41.66666667%
                    }

                    .col-md-6 {
                        -ms-flex-preferred-size: 50%;
                        flex-basis: 50%;
                        max-width: 50%
                    }

                    .col-md-7 {
                        -ms-flex-preferred-size: 58.33333333%;
                        flex-basis: 58.33333333%;
                        max-width: 58.33333333%
                    }

                    .col-md-8 {
                        -ms-flex-preferred-size: 66.66666667%;
                        flex-basis: 66.66666667%;
                        max-width: 66.66666667%
                    }

                    .col-md-9 {
                        -ms-flex-preferred-size: 75%;
                        flex-basis: 75%;
                        max-width: 75%
                    }

                    .col-md-10 {
                        -ms-flex-preferred-size: 83.33333333%;
                        flex-basis: 83.33333333%;
                        max-width: 83.33333333%
                    }

                    .col-md-11 {
                        -ms-flex-preferred-size: 91.66666667%;
                        flex-basis: 91.66666667%;
                        max-width: 91.66666667%
                    }

                    .col-md-12 {
                        -ms-flex-preferred-size: 100%;
                        flex-basis: 100%;
                        max-width: 100%
                    }

                    .col-md-offset-0 {
                        margin-left: 0
                    }

                    .col-md-offset-1 {
                        margin-left: 8.33333333%
                    }

                    .col-md-offset-2 {
                        margin-left: 16.66666667%
                    }

                    .col-md-offset-3 {
                        margin-left: 25%
                    }

                    .col-md-offset-4 {
                        margin-left: 33.33333333%
                    }

                    .col-md-offset-5 {
                        margin-left: 41.66666667%
                    }

                    .col-md-offset-6 {
                        margin-left: 50%
                    }

                    .col-md-offset-7 {
                        margin-left: 58.33333333%
                    }

                    .col-md-offset-8 {
                        margin-left: 66.66666667%
                    }

                    .col-md-offset-9 {
                        margin-left: 75%
                    }

                    .col-md-offset-10 {
                        margin-left: 83.33333333%
                    }

                    .col-md-offset-11 {
                        margin-left: 91.66666667%
                    }

                    .start-md {
                        -webkit-box-pack: start;
                        -ms-flex-pack: start;
                        justify-content: flex-start;
                        text-align: start
                    }

                    .center-md {
                        -webkit-box-pack: center;
                        -ms-flex-pack: center;
                        justify-content: center;
                        text-align: center
                    }

                    .end-md {
                        -webkit-box-pack: end;
                        -ms-flex-pack: end;
                        justify-content: flex-end;
                        text-align: end
                    }

                    .top-md {
                        -webkit-box-align: start;
                        -ms-flex-align: start;
                        align-items: flex-start
                    }

                    .middle-md {
                        -webkit-box-align: center;
                        -ms-flex-align: center;
                        align-items: center
                    }

                    .bottom-md {
                        -webkit-box-align: end;
                        -ms-flex-align: end;
                        align-items: flex-end
                    }

                    .around-md {
                        -ms-flex-pack: distribute;
                        justify-content: space-around
                    }

                    .between-md {
                        -webkit-box-pack: justify;
                        -ms-flex-pack: justify;
                        justify-content: space-between
                    }

                    .first-md {
                        -webkit-box-ordinal-group: 0;
                        -ms-flex-order: -1;
                        order: -1
                    }

                    .last-md {
                        -webkit-box-ordinal-group: 2;
                        -ms-flex-order: 1;
                        order: 1
                    }
                }

                @media only screen and (min-width:75em) {
                    .container {
                        width: 76rem
                    }

                    .col-lg,
                    .col-lg-1,
                    .col-lg-10,
                    .col-lg-11,
                    .col-lg-12,
                    .col-lg-2,
                    .col-lg-3,
                    .col-lg-4,
                    .col-lg-5,
                    .col-lg-6,
                    .col-lg-7,
                    .col-lg-8,
                    .col-lg-9,
                    .col-lg-offset-0,
                    .col-lg-offset-1,
                    .col-lg-offset-10,
                    .col-lg-offset-11,
                    .col-lg-offset-12,
                    .col-lg-offset-2,
                    .col-lg-offset-3,
                    .col-lg-offset-4,
                    .col-lg-offset-5,
                    .col-lg-offset-6,
                    .col-lg-offset-7,
                    .col-lg-offset-8,
                    .col-lg-offset-9 {
                        box-sizing: border-box;
                        -webkit-box-flex: 0;
                        -ms-flex: 0 0 auto;
                        flex: 0 0 auto;
                        padding-right: .5rem;
                        padding-left: .5rem
                    }

                    .col-lg {
                        -webkit-box-flex: 1;
                        -ms-flex-positive: 1;
                        flex-grow: 1;
                        -ms-flex-preferred-size: 0;
                        flex-basis: 0;
                        max-width: 100%
                    }

                    .col-lg-1 {
                        -ms-flex-preferred-size: 8.33333333%;
                        flex-basis: 8.33333333%;
                        max-width: 8.33333333%
                    }

                    .col-lg-2 {
                        -ms-flex-preferred-size: 16.66666667%;
                        flex-basis: 16.66666667%;
                        max-width: 16.66666667%
                    }

                    .col-lg-3 {
                        -ms-flex-preferred-size: 25%;
                        flex-basis: 25%;
                        max-width: 25%
                    }

                    .col-lg-4 {
                        -ms-flex-preferred-size: 33.33333333%;
                        flex-basis: 33.33333333%;
                        max-width: 33.33333333%
                    }

                    .col-lg-5 {
                        -ms-flex-preferred-size: 41.66666667%;
                        flex-basis: 41.66666667%;
                        max-width: 41.66666667%
                    }

                    .col-lg-6 {
                        -ms-flex-preferred-size: 50%;
                        flex-basis: 50%;
                        max-width: 50%
                    }

                    .col-lg-7 {
                        -ms-flex-preferred-size: 58.33333333%;
                        flex-basis: 58.33333333%;
                        max-width: 58.33333333%
                    }

                    .col-lg-8 {
                        -ms-flex-preferred-size: 66.66666667%;
                        flex-basis: 66.66666667%;
                        max-width: 66.66666667%
                    }

                    .col-lg-9 {
                        -ms-flex-preferred-size: 75%;
                        flex-basis: 75%;
                        max-width: 75%
                    }

                    .col-lg-10 {
                        -ms-flex-preferred-size: 83.33333333%;
                        flex-basis: 83.33333333%;
                        max-width: 83.33333333%
                    }

                    .col-lg-11 {
                        -ms-flex-preferred-size: 91.66666667%;
                        flex-basis: 91.66666667%;
                        max-width: 91.66666667%
                    }

                    .col-lg-12 {
                        -ms-flex-preferred-size: 100%;
                        flex-basis: 100%;
                        max-width: 100%
                    }

                    .col-lg-offset-0 {
                        margin-left: 0
                    }

                    .col-lg-offset-1 {
                        margin-left: 8.33333333%
                    }

                    .col-lg-offset-2 {
                        margin-left: 16.66666667%
                    }

                    .col-lg-offset-3 {
                        margin-left: 25%
                    }

                    .col-lg-offset-4 {
                        margin-left: 33.33333333%
                    }

                    .col-lg-offset-5 {
                        margin-left: 41.66666667%
                    }

                    .col-lg-offset-6 {
                        margin-left: 50%
                    }

                    .col-lg-offset-7 {
                        margin-left: 58.33333333%
                    }

                    .col-lg-offset-8 {
                        margin-left: 66.66666667%
                    }

                    .col-lg-offset-9 {
                        margin-left: 75%
                    }

                    .col-lg-offset-10 {
                        margin-left: 83.33333333%
                    }

                    .col-lg-offset-11 {
                        margin-left: 91.66666667%
                    }

                    .start-lg {
                        -webkit-box-pack: start;
                        -ms-flex-pack: start;
                        justify-content: flex-start;
                        text-align: start
                    }

                    .center-lg {
                        -webkit-box-pack: center;
                        -ms-flex-pack: center;
                        justify-content: center;
                        text-align: center
                    }

                    .end-lg {
                        -webkit-box-pack: end;
                        -ms-flex-pack: end;
                        justify-content: flex-end;
                        text-align: end
                    }

                    .top-lg {
                        -webkit-box-align: start;
                        -ms-flex-align: start;
                        align-items: flex-start
                    }

                    .middle-lg {
                        -webkit-box-align: center;
                        -ms-flex-align: center;
                        align-items: center
                    }

                    .bottom-lg {
                        -webkit-box-align: end;
                        -ms-flex-align: end;
                        align-items: flex-end
                    }

                    .around-lg {
                        -ms-flex-pack: distribute;
                        justify-content: space-around
                    }

                    .between-lg {
                        -webkit-box-pack: justify;
                        -ms-flex-pack: justify;
                        justify-content: space-between
                    }

                    .first-lg {
                        -webkit-box-ordinal-group: 0;
                        -ms-flex-order: -1;
                        order: -1
                    }

                    .last-lg {
                        -webkit-box-ordinal-group: 2;
                        -ms-flex-order: 1;
                        order: 1
                    }
                }
            </style>

            <!-- HEADER -->
            <section class="row middle-xs">
                <article class="col-xs-6">
                    <h1>Career Portal Configuration</h1>
                </article>
                <article class="col-xs-6">
                    <div class="row end-xs">
                        <div class="col-xs-6">
                            <!-- LOGO -->
                            <svg id="bh-logo" width="155px" height="59px" viewBox="0 0 155 59" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                <defs>
                                    <polygon id="path-1" points="0.00948665298 0.0306735113 0.00948665298 21.0179959 17.4793162 21.0179959 17.4793162 0.0306735113 0.00948665298 0.0306735113"></polygon>
                                </defs>
                                <g id="BH16_logo_gray_linear" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <g id="Group-3" transform="translate(0.000000, 34.310062)">
                                        <mask id="mask-2" fill="white">
                                            <use xlink:href="#path-1"></use>
                                        </mask>
                                        <g id="Clip-2"></g>
                                        <path d="M9.74405749,17.719961 C11.0034107,17.719961 11.9927105,17.4813717 12.7122731,17.0038768 C13.4316776,16.5271725 13.791538,15.8110883 13.791538,14.856731 L13.791538,14.796807 C13.791538,13.9022156 13.4364209,13.211271 12.7272936,12.7241314 C12.0175339,12.2368337 10.9330513,11.9933429 9.47432033,11.9933429 L4.12732649,11.9933429 C3.851423,11.9933429 3.62785421,12.2169117 3.62785421,12.4928152 L3.62785421,17.2204887 C3.62785421,17.4963922 3.851423,17.719961 4.12732649,17.719961 L9.74405749,17.719961 Z M8.6646345,8.8753963 C9.86390554,8.8753963 10.8234805,8.64202464 11.542885,8.17449076 C12.2624476,7.70743121 12.622308,6.99672279 12.622308,6.04268172 L12.622308,5.98244148 C12.622308,5.14777413 12.3075092,4.49698973 11.6779117,4.02929774 C11.0483142,3.5623963 10.1338008,3.32855031 8.93452977,3.32855031 L4.12732649,3.32855031 C3.851423,3.32855031 3.62785421,3.5521191 3.62785421,3.8281807 L3.62785421,8.37592402 C3.62785421,8.6516694 3.851423,8.8753963 4.12732649,8.8753963 L8.6646345,8.8753963 Z M0,0.530145791 C0,0.254400411 0.223568789,0.0306735113 0.499472279,0.0306735113 L9.41423819,0.0306735113 C11.8325441,0.0306735113 13.6612546,0.650626283 14.9010021,1.88974127 C15.8401807,2.82923614 16.3100862,3.98834702 16.3100862,5.36739014 L16.3100862,5.42747228 C16.3100862,6.04726694 16.2248645,6.60713758 16.0552115,7.10629363 C15.8852423,7.60608214 15.6654682,8.04088706 15.3955729,8.41070842 C15.1258357,8.780846 14.8108789,9.10497331 14.4511766,9.38514579 C14.3553614,9.45977413 14.2579651,9.53155647 14.1591458,9.60049281 C13.840078,9.82295483 13.8723326,10.30377 14.2258686,10.466308 C15.0546858,10.8464066 15.7543265,11.3254825 16.3251068,11.9033778 C17.0943162,12.6830226 17.4793162,13.7823676 17.4793162,15.2014127 L17.4793162,15.2613368 C17.4793162,16.201306 17.2941684,17.0302813 16.9246632,17.7498439 C16.5546838,18.4695647 16.0299138,19.0691211 15.3506694,19.5486715 C14.6707926,20.028538 13.8563634,20.3934579 12.9070657,20.643115 C11.9576099,20.8932464 10.8932074,21.0179959 9.71401643,21.0179959 L0.499472279,21.0179959 C0.223568789,21.0179959 0,20.794269 0,20.5185236 L0,0.530145791 L0,0.530145791 Z" id="Fill-1" fill="#566064" mask="url(#mask-2)"></path>
                                    </g>
                                    <path d="M36.2749055,34.1540062 L38.9047639,34.1540062 C39.212922,34.1540062 39.4628953,34.4038214 39.4628953,34.7121376 L39.4628953,54.7699261 C39.4628953,55.0780842 39.212922,55.3278994 38.9047639,55.3278994 L36.2749055,55.3278994 C35.9665893,55.3278994 35.716616,55.0780842 35.716616,54.7699261 L35.716616,34.7121376 C35.716616,34.4038214 35.9665893,34.1540062 36.2749055,34.1540062" id="Fill-4" fill="#566064"></path>
                                    <path d="M42.8284435,34.1540062 L45.4583018,34.1540062 C45.76646,34.1540062 46.0164333,34.4038214 46.0164333,34.7121376 L46.0164333,54.7699261 C46.0164333,55.0780842 45.76646,55.3278994 45.4583018,55.3278994 L42.8284435,55.3278994 C42.5202854,55.3278994 42.2703121,55.0780842 42.2703121,54.7699261 L42.2703121,34.7121376 C42.2703121,34.4038214 42.5202854,34.1540062 42.8284435,34.1540062" id="Fill-5" fill="#566064"></path>
                                    <path d="M48.8241663,34.1540062 L50.6301088,34.1540062 C51.6665257,34.1540062 52.5065688,34.9943655 52.5065688,36.0304661 L52.5065688,41.963577 C52.887616,41.5403142 53.4432177,41.1278029 54.1732156,40.7254107 C54.9033717,40.3236509 55.8398624,40.1220595 56.9826879,40.1220595 C57.8924579,40.1220595 58.7072033,40.2706838 59.4270821,40.5665092 C60.1463285,40.8634415 60.744462,41.2808542 61.220692,41.8204867 C61.6967639,42.3602772 62.0618419,43.0110616 62.315768,43.7726817 C62.5698522,44.5346181 62.6968152,45.3710246 62.6968152,46.2806366 L62.6968152,54.8137228 C62.6968152,55.0976899 62.4666057,55.3278994 62.1824805,55.3278994 L59.4651869,55.3278994 C59.1812197,55.3278994 58.9508522,55.0976899 58.9508522,54.8137228 L58.9508522,46.3124168 C58.9508522,45.3599569 58.6913922,44.6248994 58.1731047,44.1062957 C57.6543429,43.5878501 56.9826879,43.3285483 56.1573491,43.3285483 C55.6493388,43.3285483 55.1731088,43.4291068 54.7288172,43.6302238 C54.2843676,43.8311828 53.9033203,44.1116715 53.5858337,44.4710575 C53.2685051,44.8313922 53.0194805,45.248963 52.8400246,45.725193 C52.6599363,46.2012649 52.5701294,46.714809 52.5701294,47.2645606 L52.5701294,54.8137228 C52.5701294,55.0976899 52.3399199,55.3278994 52.0559528,55.3278994 L49.3383429,55.3278994 C49.0543758,55.3278994 48.8241663,55.0976899 48.8241663,54.8137228 L48.8241663,34.1540062" id="Fill-6" fill="#566064"></path>
                                    <path d="M93.8636324,40.4395462 L96.2251766,40.4395462 C96.559423,40.4395462 96.8356427,40.700271 96.8544579,41.0340431 L96.9158049,42.1223203 C97.1064867,41.9109261 97.333692,41.6884641 97.5985277,41.4554086 C97.8628891,41.2228275 98.1802177,41.0062156 98.5506715,40.8047823 C98.9209671,40.6036653 99.3390123,40.4395462 99.804807,40.3125832 C100.269969,40.1856201 100.799324,40.1219014 101.392082,40.1219014 C103.253996,40.1219014 104.672251,40.6776612 105.645739,41.7885483 C106.61907,42.8997515 107.106209,44.3972197 107.106209,46.2806366 L107.106209,54.6617782 C107.106209,55.0297023 106.807854,55.3278994 106.43993,55.3278994 L104.026526,55.3278994 C103.658602,55.3278994 103.360088,55.0297023 103.360088,54.6617782 L103.360088,46.3124168 C103.360088,45.3597988 103.100786,44.6248994 102.582341,44.1061376 C102.063737,43.5878501 101.392082,43.3285483 100.566427,43.3285483 C100.058575,43.3285483 99.5825031,43.4291068 99.1378953,43.6302238 C98.6937618,43.8311828 98.3125565,44.1116715 97.9952279,44.4710575 C97.6778994,44.8312341 97.4288747,45.248963 97.2494189,45.725193 C97.0691725,46.2012649 96.9795236,46.714809 96.9795236,47.2647187 L96.9795236,54.6617782 C96.9795236,55.0297023 96.6813265,55.3278994 96.3134025,55.3278994 L93.8995236,55.3278994 C93.5315996,55.3278994 93.2334025,55.0297023 93.2334025,54.6617782 L93.2334025,41.06946 C93.2334025,40.7214579 93.5156304,40.4395462 93.8636324,40.4395462" id="Fill-7" fill="#566064"></path>
                                    <path d="M109.624916,41.2595092 L109.624916,41.6993737 L109.993947,41.6993737 C110.105099,41.6993737 110.180676,41.6865667 110.22052,41.6614271 C110.279021,41.6255359 110.309062,41.5640308 110.309062,41.4775441 C110.309062,41.4022834 110.287717,41.3466283 110.245659,41.3121602 C110.203444,41.2770595 110.123598,41.2595092 110.008018,41.2595092 L109.624916,41.2595092 Z M109.390595,41.0443203 L110.012604,41.0443203 C110.158382,41.0443203 110.262261,41.0585503 110.325979,41.0878008 C110.390172,41.1167351 110.442823,41.163694 110.482825,41.2294682 C110.522828,41.2952423 110.543698,41.3719261 110.543698,41.4588871 C110.543698,41.5344641 110.528994,41.5992895 110.501483,41.6543121 C110.479663,41.6944723 110.432546,41.7387433 110.359025,41.7866509 C110.425747,41.819538 110.470335,41.8574846 110.494526,41.900807 C110.516977,41.9439713 110.528678,42.017809 110.528678,42.1231109 L110.528678,42.2902341 C110.528678,42.3686571 110.545912,42.4342731 110.580696,42.4861335 L110.605361,42.5259774 L110.342265,42.5259774 C110.324398,42.4654209 110.312856,42.392848 110.306532,42.3084168 L110.294515,42.1272218 C110.290246,42.0609733 110.278546,42.0138563 110.261945,41.9861869 C110.245185,41.9588337 110.220203,41.9397023 110.18953,41.9272115 C110.158066,41.9151951 110.094663,41.9095031 110.000429,41.9095031 L109.624916,41.9095031 L109.624916,42.5259774 L109.390595,42.5259774 L109.390595,41.0443203 Z M111.045226,41.7943984 C111.045226,41.5973922 110.995579,41.4125606 110.895021,41.239271 C110.795727,41.0662977 110.659593,40.9295318 110.488201,40.8300801 C110.316967,40.7306283 110.132294,40.6806653 109.934971,40.6806653 C109.736226,40.6806653 109.549339,40.7306283 109.375575,40.8300801 C109.201969,40.9295318 109.065045,41.0662977 108.966226,41.239271 C108.866142,41.4125606 108.817444,41.5992895 108.817444,41.7978768 C108.817444,41.9956735 108.866142,42.1806632 108.966226,42.3525298 C109.065045,42.5245544 109.202127,42.6597392 109.377314,42.7593491 C109.551236,42.8588008 109.737491,42.9084476 109.934971,42.9084476 C110.131345,42.9084476 110.315228,42.8588008 110.488201,42.7585585 C110.660858,42.6583162 110.796676,42.5231314 110.895495,42.3517392 C110.995579,42.1801889 111.045226,41.994883 111.045226,41.7943984 L111.045226,41.7943984 Z M111.221836,41.7923429 C111.221836,42.0242916 111.164441,42.240271 111.049337,42.4390164 C110.934074,42.6376037 110.775963,42.7953984 110.576111,42.9116099 C110.375152,43.0275051 110.160595,43.0856899 109.932283,43.0856899 C109.70239,43.0856899 109.487676,43.0276632 109.28814,42.9122423 C109.087181,42.7968214 108.929228,42.6391848 108.813333,42.4399651 C108.697912,42.240271 108.640359,42.0265051 108.640359,41.7989836 C108.640359,41.5689322 108.697912,41.3527947 108.813333,41.1515195 C108.929228,40.94977 109.087181,40.791501 109.286559,40.6765544 C109.486569,40.5614497 109.702232,40.5037392 109.932283,40.5037392 C110.162177,40.5037392 110.375626,40.5614497 110.57532,40.6757639 C110.773749,40.790078 110.931386,40.9485051 111.047281,41.1497803 C111.164125,41.3512136 111.221836,41.5654538 111.221836,41.7923429 L111.221836,41.7923429 Z" id="Fill-8" fill="#566064"></path>
                                    <path d="M82.2782156,40.3949589 L84.6196797,40.3949589 C84.9597762,40.3949589 85.2402649,40.6615339 85.2573409,41.0011561 L85.3218501,42.2680986 C85.491345,42.0565462 85.7077988,41.8234908 85.9727926,41.5697228 C86.2369959,41.3156386 86.5491068,41.0828994 86.9091253,40.871347 C87.2688275,40.6597947 87.6868727,40.4798645 88.1629446,40.3315565 C88.6393326,40.1835647 89.1838665,40.1092526 89.7981273,40.1092526 C90.1575133,40.1092526 90.4803758,40.1305975 90.7662402,40.1728131 C90.8883018,40.1909959 91.0114702,40.2150287 91.1355873,40.2445955 C91.4176571,40.3122669 91.5969548,40.5907002 91.5354497,40.8745092 L91.0008768,43.3468891 C90.9376324,43.6401848 90.6444949,43.8174271 90.3529384,43.7472259 C90.2688234,43.7271458 90.1843922,43.7100698 90.0994867,43.6964723 C89.834809,43.6542567 89.5228563,43.6329117 89.1629959,43.6329117 C88.6549856,43.6329117 88.1680041,43.7176591 87.7028419,43.8868378 C87.2372053,44.0564908 86.8348131,44.2996653 86.4962977,44.6169938 C86.1576242,44.9344805 85.8878871,45.3153696 85.6872444,45.7598193 C85.485653,46.204269 85.3854107,46.7016858 85.3854107,47.2517536 L85.3854107,54.6551376 C85.3854107,55.0020329 85.1041314,55.2833121 84.757078,55.2833121 L82.2677803,55.2833121 C81.920885,55.2833121 81.6396057,55.0020329 81.6396057,54.6551376 L81.6396057,41.0335688 C81.6396057,40.6808234 81.9256283,40.3949589 82.2782156,40.3949589" id="Fill-9" fill="#566064"></path>
                                    <path d="M30.0379055,40.6703881 C29.7185216,40.6703881 29.4595359,40.9295318 29.4595359,41.2487577 L29.4595359,48.4847023 C29.4595359,50.466306 28.0441273,51.7969671 26.3167659,51.7969671 C25.9875791,51.7966509 25.7619548,51.7964928 25.6285092,51.796809 C23.9011478,51.796809 22.4857392,50.4661478 22.4857392,48.4845441 L22.4857392,41.2489158 C22.4857392,40.9295318 22.2269117,40.6705462 21.9075277,40.6705462 L19.6100185,40.6705462 C19.2906345,40.6705462 19.0316489,40.9295318 19.0316489,41.2489158 L19.0316489,49.2773121 C19.0316489,52.7655544 22.2242238,55.1906591 25.5983101,55.2211745 L25.5983101,55.221807 L25.6221848,55.221807 C25.6356242,55.221807 25.6490637,55.2225975 25.6625031,55.2225975 L25.6625031,55.221807 L26.2827721,55.221807 L26.2827721,55.2227556 C26.2985832,55.2227556 26.3143943,55.221807 26.3302053,55.221807 L26.4035688,55.221807 L26.4035688,55.2200678 C29.7564682,55.1631478 32.9137844,52.7461068 32.9137844,49.2774702 L32.9137844,41.2487577 C32.9137844,40.9295318 32.6547988,40.6703881 32.3354148,40.6703881 L30.0379055,40.6703881" id="Fill-10" fill="#566064"></path>
                                    <g id="Group-14" transform="translate(64.193018, 0.000000)" fill="#566064">
                                        <path d="M8.02523409,52.660885 C8.74448049,52.660885 9.36901848,52.5181109 9.89821561,52.2320883 C10.4270965,51.9466982 10.8664867,51.5708686 11.2157536,51.105232 C11.5648624,50.6400698 11.823848,50.1323758 11.9931848,49.5815175 C12.1626797,49.0312916 12.247269,48.4813819 12.247269,47.9308398 C12.247269,47.4019589 12.1626797,46.8569507 11.9931848,46.2958152 C11.823848,45.7353121 11.5648624,45.22746 11.2157536,44.7721006 C10.8664867,44.3173737 10.4270965,43.9469199 9.89821561,43.6610554 C9.36901848,43.3755072 8.74448049,43.2325749 8.02523409,43.2325749 C7.30551335,43.2325749 6.68097536,43.3755072 6.15225257,43.6610554 C5.62289733,43.9469199 5.18413963,44.3173737 4.83487269,44.7721006 C4.48576386,45.22746 4.22646201,45.7353121 4.05712526,46.2958152 C3.88731417,46.8569507 3.80319918,47.4019589 3.80319918,47.9308398 C3.80319918,48.4813819 3.88731417,49.0312916 4.05712526,49.5815175 C4.22646201,50.1323758 4.48576386,50.6400698 4.83487269,51.105232 C5.18413963,51.5708686 5.62289733,51.9466982 6.15225257,52.2320883 C6.68097536,52.5181109 7.30551335,52.660885 8.02523409,52.660885 M0.025613963,47.9308398 C0.025613963,46.8514168 0.221039014,45.8309692 0.612837782,44.8672834 C1.00416222,43.9047043 1.54932854,43.0633963 2.24770431,42.3438337 C2.94608008,41.6245873 3.78738809,41.0528583 4.77131211,40.6294374 C5.75555236,40.2063326 6.83971869,39.9946222 8.02523409,39.9946222 C9.21011704,39.9946222 10.2950739,40.2063326 11.2789979,40.6294374 C12.2632382,41.0528583 13.1043881,41.6245873 13.802922,42.3438337 C14.5011396,43.0633963 15.0458316,43.9047043 15.4374723,44.8672834 C15.8291129,45.8309692 16.0250123,46.8514168 16.0250123,47.9308398 C16.0250123,49.0102628 15.8291129,50.0313429 15.4374723,50.9942382 C15.0458316,51.9576078 14.5011396,52.803501 13.802922,53.5338152 C13.1043881,54.2641294 12.2632382,54.8409179 11.2789979,55.2637064 C10.2950739,55.6869692 9.21011704,55.8986797 8.02523409,55.8986797 C6.83971869,55.8986797 5.75555236,55.6869692 4.77131211,55.2637064 C3.78738809,54.8409179 2.94608008,54.2641294 2.24770431,53.5338152 C1.54932854,52.803501 1.00416222,51.9576078 0.612837782,50.9942382 C0.221039014,50.0313429 0.025613963,49.0102628 0.025613963,47.9308398" id="Fill-11"></path>
                                        <path d="M89.5819897,33.7754887 C89.5394579,33.7182526 89.4124949,33.6466283 89.4230883,33.5017988 C89.4578727,33.01877 89.2137495,33.1673943 89.0328706,33.2878747 C88.4089651,33.7033901 87.5931129,33.8528049 87.3954743,34.8920678 C87.3513614,35.1230678 87.1331684,35.2067084 86.9619343,35.3083737 C85.3411396,36.2701622 83.5548029,35.1254394 83.1179425,32.7899836 C82.8912115,31.5794867 82.5917495,30.3958686 82.1093532,29.2925708 C81.8489446,28.696809 81.0870082,27.9056222 80.714499,27.2831396 C80.6525195,27.1798932 80.6166283,27.0635236 80.6131499,26.9432012 C80.5944928,26.3015873 80.3219097,24.828152 78.5777885,23.8130801 C78.5651396,23.8047002 78.5523326,23.7964784 78.5395257,23.7880986 C76.4015503,22.2337105 71.8016304,20.6301499 69.3330452,19.8826016 C68.3911786,19.6223511 68.1388337,20.2283901 68.1157495,20.6110185 C68.1114805,20.6842238 68.1212834,20.7561643 68.1412053,20.8268398 C68.1897454,20.9988645 68.2923593,21.3508193 68.2937823,21.3614127 C68.8780021,23.5925154 69.6301355,26.6829507 69.1986509,26.5627864 C68.7375996,26.4344004 67.5955647,19.9804723 64.8989836,18.12346 C64.8819076,18.1095462 64.8649897,18.0962649 64.8475975,18.0823511 C63.0884559,16.4550739 59.4349877,15.6907659 58.2031458,15.4325708 C58.0425051,15.3990513 57.8978337,15.3105092 57.7996468,15.1795934 C57.0750246,14.2159076 55.9426345,13.9218214 54.1831766,13.6351663 C53.4528624,13.5162669 52.8267433,13.4261437 52.2913799,13.3610021 C51.8511992,13.3074025 51.5696037,12.8669055 51.7060534,12.4445914 L51.7084251,12.4373183 C51.7647125,12.2613409 51.7659774,11.9060657 51.651347,11.8603717 C51.5197988,11.808037 51.1082361,11.9914456 50.7597598,12.0301828 C50.5282854,12.0559548 50.2606037,11.9063819 50.2474805,11.8987926 C50.1624168,11.8491458 50.3682772,12.024807 50.2789446,11.9400595 C49.2633984,10.9774805 51.7963347,10.0893717 51.2383614,10.0506345 C51.0423039,10.037037 50.8524127,10.0322936 50.6634702,10.0283409 C49.8936283,10.0122136 49.1848172,10.0666037 48.5849446,10.1518255 C48.4269918,10.1741191 48.3267495,10.0254949 48.3405051,9.89157495 C48.3471458,9.82738193 48.3776612,9.76619302 48.4451745,9.7296694 C51.7765708,7.92024846 53.0277023,5.85215811 53.0277023,5.85215811 C53.0277023,5.85215811 54.0415092,4.20559138 51.6885031,3.11668172 C51.2396263,2.90908214 50.6685298,2.72061396 49.9421684,2.56661396 C47.9061745,2.13497125 46.0776222,1.465846 44.6672731,0.851585216 C44.170963,0.635289528 43.7255647,0.425950719 43.3434107,0.236691992 C43.3287064,0.22926078 43.2346304,0.18261807 43.1573142,0.160166324 C42.9370657,0.0762094456 42.7441704,0.142774127 42.6308049,0.417728953 C42.4436016,0.872297741 43.0708275,1.1056694 43.3993819,1.36022793 C44.7975565,2.44376181 46.3834086,3.1366037 47.8301232,4.07499179 C48.7432136,4.66711704 48.7691437,4.92894867 47.9328953,5.50383984 C46.7187618,6.33850719 45.3454107,6.85948255 43.9635216,7.37919302 C43.8888932,7.40733676 43.8171109,7.41935318 43.7464353,7.42125051 C43.0178604,6.93964476 42.2851745,6.84414579 41.6111478,6.96905339 C40.3995441,7.01854209 39.2655729,7.69525667 38.6484661,8.83254825 C38.5197639,9.06939836 38.2609363,9.2066386 37.992306,9.18529363 C37.942501,9.18134086 37.8926961,9.17849487 37.8427331,9.18023409 C37.751345,9.16394867 37.6496797,9.16268378 37.5742608,9.16853388 C34.5937125,9.39874333 34.0000062,10.6222053 33.8837947,11.1457105 C33.8498008,11.299078 33.7520883,11.4290452 33.6113696,11.4884949 C27.1988665,14.1929815 22.6827454,12.166 21.1699405,11.2753614 C21.1595051,11.269037 21.1473306,11.2622382 21.1367372,11.2560719 C20.942577,11.1404928 20.7139487,11.324692 20.7966407,11.5345051 C22.2212197,15.1599877 29.5713203,15.4423737 31.6235996,15.4483819 C31.7108768,15.4486982 31.7923039,15.44854 31.8596591,15.4480657 C32.0136591,15.4469589 32.1377762,15.6041211 32.0867064,15.7513224 C31.5601971,17.2647598 30.9307577,18.2553244 30.5340575,18.8004908 C30.3375257,19.070386 30.185423,19.3684251 30.0837577,19.6865441 L30.0415421,19.8182505 C29.863193,20.37654 29.8701499,20.9775195 30.0614641,21.53154 C30.1081068,21.6665667 30.1114271,21.8128193 30.0734805,21.950692 C30.0519774,22.0286407 30.039961,22.0838214 30.0344271,22.1385277 C30.0344271,22.1385277 30.0170349,22.2795626 30.0432813,22.4400452 C30.4271745,24.7876756 31.7073984,25.2926817 31.7073984,25.2926817 C31.7073984,25.2926817 31.9229035,25.42423 32.7651602,25.3839117 C34.7671602,25.288729 38.1317598,24.8104435 38.9672177,24.7536817 C39.0565503,24.7475154 39.1447762,24.7563696 39.2312628,24.7789795 L39.2854949,24.7930513 C39.3471581,24.8090205 39.4058172,24.8308398 39.4619466,24.8599322 C42.3553758,26.3597721 46.6669014,31.0349528 48.2113285,33.7380164 C48.2986057,33.9016612 48.3880965,34.0632505 48.4793265,34.2231006 C49.2050554,35.6043573 49.9692053,36.63777 51.2086366,37.5541807 C51.3468255,37.6563203 51.739731,37.9486674 52.3764435,38.3112156 C53.1753778,38.7661006 53.8233162,39.0303039 54.3453984,39.2409076 C55.7492649,39.8069446 56.9088501,40.1005565 57.7575893,40.3154292 C58.1214025,40.4076078 58.3601499,40.4610493 58.5119363,40.4929877 C59.1657248,40.6307023 59.7589569,40.7122875 60.5022361,40.8096838 C63.3019055,41.1766591 64.5996797,41.0297741 65.1108522,41.9205708 C65.1456366,41.9632608 65.2450883,42.3035154 65.2771848,42.4222567 C65.2811376,42.4360123 65.2854066,42.4491355 65.2893593,42.4627331 C65.9768255,44.4683696 66.4121047,44.7034805 66.7234251,45.6236858 C66.8699938,46.0561191 67.098306,46.2973963 67.4923183,46.4148727 C68.1111643,46.59923 68.6628131,46.9423306 68.9143676,47.6141437 C69.4941602,49.1615749 70.610423,50.3578419 72.0557146,50.760076 C73.6497885,51.2042094 74.3799446,51.0636489 75.3371478,49.7367823 C75.695269,49.2401561 75.7161396,48.7781561 75.4244251,48.2612916 C74.8538029,47.2506468 74.0052218,46.7666694 72.9645359,46.6389158 C72.4668029,46.5777269 71.9927864,46.3261725 71.925115,45.8153162 C71.8120657,44.9642053 71.370462,44.4652074 70.8596057,43.939963 C70.355232,43.4215175 70.476345,42.6942074 71.04254,42.359961 C71.1910062,42.2723676 72.8932279,40.9225749 73.5843306,40.5753634 C73.8308255,40.4484004 75.2995175,39.9343819 75.3461602,38.903499 C75.1338172,36.4404476 75.534154,34.684152 75.7205667,34.7002793 C75.8274497,34.709924 75.635345,35.5186612 75.9653224,37.0556571 C75.9816078,37.1318665 76.0039014,37.2058624 76.0296735,37.2784353 C76.0296735,37.2790678 76.0295154,37.2795421 76.0296735,37.2803326 C76.3338789,39.0527556 78.4435524,41.8359815 79.4829733,43.0180185 C79.5348337,43.077152 79.5743614,43.144191 79.6021889,43.2175544 C79.8121602,43.7671478 80.0877474,44.2734189 80.4310062,44.7515462 C80.5680883,44.9425441 80.7171869,45.2872259 80.7562402,45.5190164 C81.0903285,47.4999877 82.03346,49.2436345 82.2244579,51.2593901 C82.2971889,52.0257536 82.469846,52.9582916 82.3667577,53.3028152 C82.3431992,53.3810801 82.3253326,53.4604517 82.332922,53.5417207 C82.3817782,54.0845154 82.5549097,55.2926407 82.7623511,55.397152 C82.9821253,55.5076715 84.0144312,55.7168522 84.4816489,55.1960349 C84.5188049,55.1542936 84.5380945,55.0954764 84.5442608,55.0372916 C84.6354908,54.1689466 84.9877618,54.54446 85.1672177,54.779729 C85.2220821,54.8518275 85.310308,54.8763347 85.3925257,54.8451869 C85.8243265,54.682807 86.0199097,54.5073039 86.2823737,54.196616 C86.3143121,54.1591437 86.3372382,54.1104456 86.346883,54.059692 C86.4869692,53.316729 86.5208049,52.5856242 86.1745421,51.8962608 C85.8644867,51.2793121 85.4905544,50.7276632 85.0848419,50.1973593 C84.1129343,48.9256735 83.5721951,47.4881294 83.955614,45.6872464 C84.1224209,44.9031745 83.9586181,44.1820308 83.5241294,43.5813676 C83.2226119,43.1644292 83.1867207,42.7768994 83.2961335,42.2151314 C83.6270595,40.5113285 83.7364723,38.780963 83.5573326,37.0475934 C83.5298214,36.7813347 83.3826201,36.4858255 83.6169405,36.2758542 C83.8417741,36.0748953 84.0773593,36.264154 84.2881211,36.3672423 C85.3352895,36.8795216 86.3396099,36.7278932 87.3143634,36.1076242 C87.5403039,35.9639014 87.7554928,35.8190719 88.0268111,35.8190719 C89.148924,35.8200205 89.6733778,35.0822752 89.7508522,34.5964004 C89.780577,34.4093552 89.7582834,34.014078 89.5819897,33.7754887 M69.0174559,50.9567659 C69.5754292,51.6303183 70.3255072,52.1267864 70.8864846,52.8215257 C71.6334004,53.7463162 72.8279281,56.4471663 72.8364661,56.6954004 C72.8352012,57.3115585 72.3401561,57.2772485 71.8544394,57.5566304 C71.622807,57.6420103 71.4869897,57.8842361 71.2618398,57.5072998 C71.1502136,57.4258727 71.0156612,57.3896653 70.8605544,57.4567043 C70.7217331,57.5169446 70.7340657,57.7288131 70.7508255,57.9383101 C70.7614189,58.0706489 70.6810986,58.1972957 70.5645708,58.2335031 C70.1605975,58.3595175 69.7368604,58.3898747 69.2799199,58.2538994 C68.920692,58.1468583 68.6628131,58.1348419 68.5564045,57.5722834 C68.5522936,57.5567885 68.5473922,57.5393963 68.542807,57.5239014 C67.8970821,55.7854723 69.2222094,56.7940616 66.6672957,52.2445791 C66.6364641,52.1672628 66.605,52.0891561 66.5741684,52.0118398 C66.3599281,51.213538 65.907731,50.494924 65.1834251,50.0569569 C64.7473552,49.7932279 64.3969815,49.3938398 64.1915955,48.8900986 C63.7341807,47.76846 62.9380924,47.0681869 61.9095811,46.6574148 C61.2361869,46.3886263 60.5495113,46.1492464 59.8764333,45.8668604 C58.3476591,45.2257207 56.537922,44.0650287 55.2156407,42.0616057 C55.1588789,41.9752772 55.0901006,41.889423 55.0383984,41.7874415 C54.9278789,41.5697228 53.9733634,40.4227864 54.1918727,40.5010513 C56.1975092,41.3388809 60.8447043,42.1580534 63.497963,42.446922 C63.8930821,42.4900862 64.2516776,42.7356324 64.3960329,43.1060862 C64.4167454,43.1590534 64.6159651,43.4972526 64.652963,43.5551211 C65.4632813,44.826807 65.5107146,45.0252361 65.8416407,45.4783819 C66.3687823,46.2004743 67.0899261,46.867386 67.2129363,47.7768398 C67.4050411,49.1966756 68.2678522,50.051423 69.0174559,50.9567659" id="Fill-13"></path>
                                    </g>
                                </g>
                            </svg>
                        </div>
                    </div>
                </article>
            </section>
            <section class="row">
                <article class="col-xs-12">
                    <p>In an effort to make Career Portal even more accessible to the Bullhorn community, we've created a plugin to set most of the Career Portal configuration values.</p>
                    <p><strong>Note the required* fields.</strong></p>
                    <p><strong>For additional information about the configuration options, please visit our <a href="https://github.com/bullhorn/career-portal/wiki/Portal-Configuration-Options" target="_blank">wiki</a></strong></p>
                    <p><?php echo 'Current PHP version: ' . phpversion(); ?></p>
                    <p><?php global $wp_version;
                        echo 'Current Wordpress version: ' . $wp_version; ?></p>
                    <br>
                </article>
            </section>

            <!-- FORM -->
            <section id="config-app">
                <!-- ROWS -->
                <form method="post" action="options.php">
                    <?php
                    settings_fields('oscp_config');
                    ?>
                    <!-- ROWS -->
                    <?php do_settings_sections('oscp-admin'); ?>
                    <!-- SAVE CHANGES / CANCEL -->
                    <div class="row end-xs overline">
                        <div class="col-xs-2">
                            <?php submit_button(); ?>
                        </div>
                    </div>
                </form>
            </section>
        </div>
    <?php }

    public function oscp_config_page_init()
    {
        register_setting(
            'oscp_config',                  // option_group
            'oscp_config_data',             // option_name
            array($this, 'oscp_sanitize')   // sanitize_callback
        );

        add_settings_section(
            'oscp_setting_section',
            '',
            array($this, 'oscp_section_info'),
            'oscp-admin'
        );

        add_settings_field(
            'oscp_company_name',
            'Company Name',
            array($this, 'oscp_company_name_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_swim_lane',
            'Swim Lane*',
            array($this, 'oscp_swim_lane_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_fields',
            'fields to use in API requests',
            array($this, 'oscp_fields_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_job_info_chips',
            'fields to display as chips on your jobs. default is "employmentType"',
            array($this, 'oscp_job_info_chips_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_corp_token',
            'Corp Token*',
            array($this, 'oscp_corp_token_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_resume_types',
            'Accepted Resume Types*',
            array($this, 'oscp_resume_types_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_width',
            'Width*',
            array($this, 'oscp_width_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_height',
            'Height*',
            array($this, 'oscp_height_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_scrollable',
            'Scrollable',
            array($this, 'oscp_scrollable_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_locale',
            'Locale*',
            array($this, 'oscp_locale_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_gender_race_ethnicity',
            'Gender Race & Ethnicity Field*',
            array($this, 'oscp_gender_race_ethnicity_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_veteran',
            'Veteran Status Field*',
            array($this, 'oscp_veteran_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_disability',
            'Disability Field*',
            array($this, 'oscp_disability_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_filter_field',
            'Additional Field to Filter Job List (optional)',
            array($this, 'oscp_filter_field_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_filter_values',
            'Values to Filter for on the job list (comma separated)',
            array($this, 'oscp_filter_values_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_sort',
            'Sort Field for Jobs*',
            array($this, 'oscp_sort_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_consent',
            'Enable Consent Checkbox*',
            array($this, 'oscp_consent_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_sidebar_link',
            'Enable Privacy Policy link in sidebar*',
            array($this, 'oscp_sidebar_link_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_privacy_url',
            'Url for Privacy Statement',
            array($this, 'oscp_privacy_url_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );

        add_settings_field(
            'oscp_analytics_tracking_id',
            'Google Analytics Tracking ID',
            array($this, 'oscp_analytics_tracking_id_callback'),
            'oscp-admin',
            'oscp_setting_section'
        );
    }

    public function oscp_sanitize($input)
    {
        $sanitary_values = array();
        // Company Name
        if (isset($input['oscp_company_name'])) {
            $sanitary_values['oscp_company_name'] = sanitize_text_field($input['oscp_company_name']);
        }
        // Height
        if (isset($input['oscp_height']) && $input['oscp_height'] != '') {
            $sanitary_values['oscp_height'] = sanitize_text_field($input['oscp_height']);
        } else {
            $sanitary_values['oscp_height'] = '500px';
        }
        // Swim Lane
        if (isset($input['oscp_swim_lane']) && $input['oscp_swim_lane'] != '') {
            $sanitary_values['oscp_swim_lane'] = sanitize_text_field($input['oscp_swim_lane']);
        }
        // Corp Token
        if (isset($input['oscp_corp_token']) && $input['oscp_corp_token'] != '') {
            $sanitary_values['oscp_corp_token'] = sanitize_text_field($input['oscp_corp_token']);
        }
        // Resume Types
        if (isset($input['oscp_resume_types']) && $input['oscp_resume_types'] != '') {
            $sanitary_values['oscp_resume_types'] = sanitize_text_field(json_encode($input['oscp_resume_types']));
        } else {
            $sanitary_values['oscp_resume_types'] = json_encode(array('html', 'text', 'txt', 'pdf', 'doc', 'docx', 'rtf', 'odt'));
        }
        // Width
        if (isset($input['oscp_width']) && $input['oscp_width'] != '') {
            $sanitary_values['oscp_width'] = sanitize_text_field($input['oscp_width']);
        } else {
            $sanitary_values['oscp_width'] = '100%';
        }
        // Scrollable
        if (isset($input['oscp_scrollable']) && $input['oscp_scrollable'] != '') {
            $sanitary_values['oscp_scrollable'] = sanitize_text_field($input['oscp_scrollable']);
        } else {
            $sanitary_values['oscp_scrollable'] = 'yes';
        }
        // Locale
        if (isset($input['oscp_locale']) && $input['oscp_locale'] != '') {
            $sanitary_values['oscp_locale'] = sanitize_text_field($input['oscp_locale']);
        } else {
            $sanitary_values['oscp_locale'] = 'en-US';
        }
        // EEOC
        // genderRaceEthnicity
        if (isset($input['oscp_gender_race_ethnicity']) && $input['oscp_gender_race_ethnicity'] != '') {
            $sanitary_values['oscp_gender_race_ethnicity'] = sanitize_text_field($input['oscp_gender_race_ethnicity']);
        } else {
            $sanitary_values['oscp_gender_race_ethnicity'] = 'false';
        }
        // veteran
        if (isset($input['oscp_veteran']) && $input['oscp_veteran'] != '') {
            $sanitary_values['oscp_veteran'] = sanitize_text_field($input['oscp_veteran']);
        } else {
            $sanitary_values['oscp_veteran'] = 'false';
        }
        // disability
        if (isset($input['oscp_disability']) && $input['oscp_disability'] != '') {
            $sanitary_values['oscp_disability'] = sanitize_text_field($input['oscp_disability']);
        } else {
            $sanitary_values['oscp_disability'] = 'false';
        }
        // additional job filter
        if (isset($input['oscp_filter_field']) && $input['oscp_filter_field'] != '') {
            $sanitary_values['oscp_filter_field'] = sanitize_text_field($input['oscp_filter_field']);
        } else {
            $sanitary_values['oscp_filter_field'] = '[ FILTER FIELD HERE ]';
        }
        // additional job filter value
        if (isset($input['oscp_filter_values']) && $input['oscp_filter_values'] != '') {
            $sanitary_values['oscp_filter_values'] = sanitize_text_field($input['oscp_filter_values']);
        } else {
            $sanitary_values['oscp_filter_values'] = '[ FILTER VALUE HERE ]';
        }
        // sort
        if (isset($input['oscp_sort']) && $input['oscp_sort'] != '') {
            $sanitary_values['oscp_sort'] = sanitize_text_field($input['oscp_sort']);
        } else {
            $sanitary_values['oscp_sort'] = '-dateLastPublished';
        }
        // Consent checkbox
        if (isset($input['oscp_consent']) && $input['oscp_consent'] != '') {
            $sanitary_values['oscp_consent'] = sanitize_text_field($input['oscp_consent']);
        } else {
            $sanitary_values['oscp_consent'] = 'false';
        }

        if (isset($input['oscp_sidebar_link']) && $input['oscp_sidebar_link'] != '') {
            $sanitary_values['oscp_sidebar_link'] = sanitize_text_field($input['oscp_sidebar_link']);
        } else {
            $sanitary_values['oscp_sidebar_link'] = 'false';
        }
        // privacy statement paragraph
        if (isset($input['oscp_privacy_statement'])) {
            $sanitary_values['oscp_privacy_statement'] = sanitize_text_field($input['oscp_privacy_statement']);
        }
        // privacy statement url
        if (isset($input['oscp_privacy_url'])) {
            $sanitary_values['oscp_privacy_url'] = sanitize_text_field($input['oscp_privacy_url']);
        }
        // use privacy statement url
        if (isset($input['oscp_use_privacy_url']) && $input['oscp_use_privacy_url'] != '') {
            $sanitary_values['oscp_use_privacy_url'] = sanitize_text_field($input['oscp_use_privacy_url']);
        } else {
            $sanitary_values['oscp_use_privacy_url'] = 'false';
        }

        if (isset($input['oscp_fields']) && $input['oscp_fields'] != '') {
            $sanitary_values['oscp_fields'] = sanitize_text_field($input['oscp_fields']);
        } else {
            $sanitary_values['oscp_fields'] = 'id,title,publishedCategory(id,name),address(city,state,countryName),employmentType,dateLastPublished,publicDescription,isOpen,isPublic,isDeleted,publishedZip,salary,salaryUnit';
        }

        if (isset($input['oscp_job_info_chips']) && $input['oscp_job_info_chips'] != '') {
            $sanitary_values['oscp_job_info_chips'] = sanitize_text_field($input['oscp_job_info_chips']);
        } else {
            $sanitary_values['oscp_job_info_chips'] = 'employmentType';
        }

        if (isset($input['oscp_analytics_tracking_id']) && $input['oscp_analytics_tracking_id'] != '') {
            $sanitary_values['oscp_analytics_tracking_id'] = sanitize_text_field($input['oscp_analytics_tracking_id']);
        } else {
            $sanitary_values['oscp_analytics_tracking_id'] = '';
        }

        return $sanitary_values;
    }

    public function oscp_section_info() {}


    public function oscp_company_name_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_company_name]" id="oscp_company_name" value="%s">',
            isset($this->oscp_options['oscp_company_name']) ? esc_attr($this->oscp_options['oscp_company_name']) : ''
        );
    }

    public function oscp_swim_lane_callback()
    {
        printf(
            '<input class="regular-text" type="number" name="oscp_config_data[oscp_swim_lane]" id="oscp_swim_lane" value="%s">',
            isset($this->oscp_options['oscp_swim_lane']) ? esc_attr($this->oscp_options['oscp_swim_lane']) : ''
        );
    }

    public function oscp_fields_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_fields]" id="oscp_fields" value="%s">',
            isset($this->oscp_options['oscp_fields']) ? esc_attr($this->oscp_options['oscp_fields']) : 'id,title,publishedCategory(id,name),address(city,state,countryName),employmentType,dateLastPublished,publicDescription,isOpen,isPublic,isDeleted,publishedZip,salary,salaryUnit'
        );
    }

    public function oscp_job_info_chips_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_job_info_chips]" id="oscp_job_info_chips" value="%s">',
            isset($this->oscp_options['oscp_job_info_chips']) ? esc_attr($this->oscp_options['oscp_job_info_chips']) : ''
        );
    }

    public function oscp_analytics_tracking_id_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_analytics_tracking_id]" id="oscp_analytics_tracking_id" value="%s">',
            isset($this->oscp_options['oscp_analytics_tracking_id']) ? esc_attr($this->oscp_options['oscp_analytics_tracking_id']) : ''
        );
    }

    public function oscp_corp_token_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_corp_token]" id="oscp_corp_token" value="%s">',
            isset($this->oscp_options['oscp_corp_token']) ? esc_attr($this->oscp_options['oscp_corp_token']) : ''
        );
    }

    public function oscp_height_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_height]" id="oscp_height" value="%s">',
            isset($this->oscp_options['oscp_height']) ? esc_attr($this->oscp_options['oscp_height']) : '500px'
        );
    }

    public function oscp_width_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_width]" id="oscp_width" value="%s">',
            isset($this->oscp_options['oscp_width']) ? esc_attr($this->oscp_options['oscp_width']) : '100%'
        );
    }

    public function oscp_scrollable_callback()
    {
        $scrollableConfig = array(
            array(
                'label' => 'Yes',
                'value' => 'yes'
            ),
            array(
                'label' => 'No',
                'value' => 'no'
            )
        );
        if (!isset($this->oscp_options['oscp_scrollable']) || $this->oscp_options['oscp_scrollable'] == '') {
            $this->oscp_options['oscp_scrollable'] = 'yes';
        }
    ?>
        <fieldset>
            <?php
            foreach ($scrollableConfig as $inputItem) {
                $checked = (isset($this->oscp_options['oscp_scrollable']) && $this->oscp_options['oscp_scrollable'] === $inputItem['value']) ? 'checked' : '';
                $inputName = 'oscp-scrollable-' . $inputItem['value'];
            ?>
                <label for="<?php echo $inputName; ?>">
                    <input type="radio" name="oscp_config_data[oscp_scrollable]" id="<?php echo $inputName; ?>" value="<?php echo $inputItem['value']; ?>" <?php echo $checked; ?>>
                    <?php echo $inputItem['label']; ?>
                </label>
                <br>
            <?php
            }
            ?>
        </fieldset>
    <?php
    }

    public function oscp_resume_types_callback()
    {
        $resumeTypes = array(
            'html',
            'text',
            'txt',
            'pdf',
            'doc',
            'docx',
            'rtf',
            'odt'
        );
        if (true) {
            $this->oscp_options['oscp_resume_types'] = json_encode($resumeTypes);
        }
        $activeTypes = json_decode($this->oscp_options['oscp_resume_types']);
    ?>
        <?php
        foreach ($resumeTypes as $type) {
            $selected = (isset($this->oscp_options['oscp_resume_types']) && in_array($type, $activeTypes)) ? 'checked' : '';
        ?>

            <label for="<?php echo $type ?>"> <?php echo $type ?> <input type="checkbox" <?php echo $selected ?> name="oscp_config_data[oscp_resume_types][]" value="<?php echo $type ?>" id="<?php echo $type ?>" /> </label>
        <?php
        }
        ?>
    <?php
    }

    public function oscp_gender_race_ethnicity_callback()
    {
        $booleanOptions = array(
            array(
                'label' => 'Enabled',
                'value' => 'true'
            ),
            array(
                'label' => 'Disabled',
                'value' => 'false'
            )
        );
        if (!isset($this->oscp_options['oscp_gender_race_ethnicity']) || $this->oscp_options['oscp_gender_race_ethnicity'] == '') {
            $this->oscp_options['oscp_gender_race_ethnicity'] = 'false';
        }
    ?>
        <fieldset>
            <?php
            foreach ($booleanOptions as $inputItem) {
                $checked = (isset($this->oscp_options['oscp_gender_race_ethnicity']) && $this->oscp_options['oscp_gender_race_ethnicity'] === $inputItem['value']) ? 'checked' : '';
                $inputName = 'oscp-gender-race-ethnicity-' . $inputItem['value'];
            ?>
                <label for="<?php echo $inputName; ?>">
                    <input type="radio" name="oscp_config_data[oscp_gender_race_ethnicity]" id="<?php echo $inputName; ?>" value="<?php echo $inputItem['value']; ?>" <?php echo $checked; ?>>
                    <?php echo $inputItem['label']; ?>
                </label>
                <br>
            <?php
            }
            ?>
        </fieldset>
    <?php
    }

    public function oscp_veteran_callback()
    {
        $booleanOptions = array(
            array(
                'label' => 'Enabled',
                'value' => 'true'
            ),
            array(
                'label' => 'Disabled',
                'value' => 'false'
            )
        );
        if (!isset($this->oscp_options['oscp_veteran']) || $this->oscp_options['oscp_veteran'] == '') {
            $this->oscp_options['oscp_veteran'] = 'false';
        }
    ?>
        <fieldset>
            <?php
            foreach ($booleanOptions as $inputItem) {
                $checked = (isset($this->oscp_options['oscp_veteran']) && $this->oscp_options['oscp_veteran'] === $inputItem['value']) ? 'checked' : '';
                $inputName = 'oscp-veteran-' . $inputItem['value'];
            ?>
                <label for="<?php echo $inputName; ?>">
                    <input type="radio" name="oscp_config_data[oscp_veteran]" id="<?php echo $inputName; ?>" value="<?php echo $inputItem['value']; ?>" <?php echo $checked; ?>>
                    <?php echo $inputItem['label']; ?>
                </label>
                <br>
            <?php
            }
            ?>
        </fieldset>
    <?php
    }

    public function oscp_disability_callback()
    {
        $booleanOptions = array(
            array(
                'label' => 'Enabled',
                'value' => 'true'
            ),
            array(
                'label' => 'Disabled',
                'value' => 'false'
            )
        );
        if (!isset($this->oscp_options['oscp_disability']) || $this->oscp_options['oscp_disability'] == '') {
            $this->oscp_options['oscp_disability'] = 'false';
        }
    ?>
        <fieldset>
            <?php
            foreach ($booleanOptions as $inputItem) {
                $checked = (isset($this->oscp_options['oscp_disability']) && $this->oscp_options['oscp_disability'] === $inputItem['value']) ? 'checked' : '';
                $inputName = 'oscp-disability-' . $inputItem['value'];
            ?>
                <label for="<?php echo $inputName; ?>">
                    <input type="radio" name="oscp_config_data[oscp_disability]" id="<?php echo $inputName; ?>" value="<?php echo $inputItem['value']; ?>" <?php echo $checked; ?>>
                    <?php echo $inputItem['label']; ?>
                </label>
                <br>
            <?php
            }
            ?>
        </fieldset>
    <?php
    }

    public function oscp_locale_callback()
    {
        $localeConfig = array(
            array(
                'label' => 'English (US)',
                'value' => 'en-US'
            ),
            array(
                'label' => 'French',
                'value' => 'fr-FR'
            )
        );
        if (!isset($this->oscp_options['oscp_locale']) || $this->oscp_options['oscp_locale'] == '') {
            $this->oscp_options['oscp_locale'] = 'en-US';
        }
    ?>
        <fieldset>
            <?php
            foreach ($localeConfig as $inputItem) {
                $checked = (isset($this->oscp_options['oscp_locale']) && $this->oscp_options['oscp_locale'] === $inputItem['value']) ? 'checked' : '';
                $inputName = 'oscp-locale-' . $inputItem['value'];
            ?>
                <label for="<?php echo $inputName; ?>">
                    <input type="radio" name="oscp_config_data[oscp_locale]" id="<?php echo $inputName; ?>" value="<?php echo $inputItem['value']; ?>" <?php echo $checked; ?>>
                    <?php echo $inputItem['label']; ?>
                </label>
                <br>
            <?php
            }
            ?>
        </fieldset>
    <?php
    }


    public function oscp_filter_field_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_filter_field]" id="oscp_filter_field" value="%s">',
            isset($this->oscp_options['oscp_filter_field']) ? esc_attr($this->oscp_options['oscp_filter_field']) : ''
        );
    }

    public function oscp_filter_values_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_filter_values]" id="oscp_filter_values" value="%s">',
            isset($this->oscp_options['oscp_filter_values']) ? esc_attr($this->oscp_options['oscp_filter_values']) : ''
        );
    }

    public function oscp_sort_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_sort]" id="oscp_sort" value="%s">',
            isset($this->oscp_options['oscp_sort']) ? esc_attr($this->oscp_options['oscp_sort']) : ''
        );
    }

    public function oscp_consent_callback()
    {
        $booleanOptions = array(
            array(
                'label' => 'Enabled',
                'value' => 'true'
            ),
            array(
                'label' => 'Disabled',
                'value' => 'false'
            )
        );
        if (!isset($this->oscp_options['oscp_consent']) || $this->oscp_options['oscp_consent'] == '') {
            $this->oscp_options['oscp_consent'] = 'false';
        }
    ?>
        <fieldset>
            <?php
            foreach ($booleanOptions as $inputItem) {
                $checked = (isset($this->oscp_options['oscp_consent']) && $this->oscp_options['oscp_consent'] === $inputItem['value']) ? 'checked' : '';
                $inputName = 'oscp_consent-' . $inputItem['value'];
            ?>
                <label for="<?php echo $inputName; ?>">
                    <input type="radio" name="oscp_config_data[oscp_consent]" id="<?php echo $inputName; ?>" value="<?php echo $inputItem['value']; ?>" <?php echo $checked; ?>>
                    <?php echo $inputItem['label']; ?>
                </label>
                <br>
            <?php
            }
            ?>
        </fieldset>
    <?php
    }

    public function oscp_sidebar_link_callback()
    {
        $booleanOptions = array(
            array(
                'label' => 'Enabled',
                'value' => 'true'
            ),
            array(
                'label' => 'Disabled',
                'value' => 'false'
            )
        );
        if (!isset($this->oscp_options['oscp_sidebar_link']) || $this->oscp_options['oscp_sidebar_link'] == '') {
            $this->oscp_options['oscp_sidebar_link'] = 'false';
        }
    ?>
        <fieldset>
            <?php
            foreach ($booleanOptions as $inputItem) {
                $checked = (isset($this->oscp_options['oscp_sidebar_link']) && $this->oscp_options['oscp_sidebar_link'] === $inputItem['value']) ? 'checked' : '';
                $inputName = 'oscp_sidebar_link-' . $inputItem['value'];
            ?>
                <label for="<?php echo $inputName; ?>">
                    <input type="radio" name="oscp_config_data[oscp_sidebar_link]" id="<?php echo $inputName; ?>" value="<?php echo $inputItem['value']; ?>" <?php echo $checked; ?>>
                    <?php echo $inputItem['label']; ?>
                </label>
                <br>
            <?php
            }
            ?>
        </fieldset>
<?php
    }

    public function oscp_privacy_url_callback()
    {
        printf(
            '<input class="regular-text" type="text" name="oscp_config_data[oscp_privacy_url]" id="oscp_privacy_url" value="%s">',
            isset($this->oscp_options['oscp_privacy_url']) ? esc_attr($this->oscp_options['oscp_privacy_url']) : ''
        );
    }
}
if (is_admin())
    $oscp = new OSCP_Config();

// Plugin Config
function oscp_plugin_add_shortcode($atts)
{
    $oscp_options = get_option('oscp_config_data');
    $oscpConfig = array(
        'src' => plugins_url('index.html', __FILE__) . '#/',
        'width' => esc_attr($oscp_options['oscp_width']),
        'height' => esc_attr($oscp_options['oscp_height']),
        'scrolling' => esc_attr($oscp_options['oscp_scrollable']),
        'class' => 'iframe-class',
        'frameborder' => '0'
    );

    oscp_save_file(true);

    $html = "\n" . '<!-- oscp plugin v' . OSCP_PLUGIN_VERSION . ' -->' . "\n";
    $html .= '<iframe';
    foreach ($oscpConfig as $attr => $value) {
        if (
            strtolower($attr) != 'same_height_as'
            and strtolower($attr) != 'onload'
            and strtolower($attr) != 'onpageshow'
            and strtolower($attr) != 'onclick'
        ) {
            if ($value != '') {
                $html .= ' ' . esc_attr($attr) . '="' . esc_attr($value) . '"';
            } else {
                $html .= ' ' . esc_attr($attr);
            }
        }
    }
    $html .= '></iframe>' . "\n";

    if (isset($atts["same_height_as"])) {
        $html .= '
			<script>
			document.addEventListener("DOMContentLoaded", function(){
				var target_element, iframe_element;
				iframe_element = document.querySelector("iframe.' . esc_attr($atts["class"]) . '");
				target_element = document.querySelector("' . esc_attr($atts["same_height_as"]) . '");
				iframe_element.style.height = target_element.offsetHeight + "px";
			});
			</script>
		';
    }

    return $html;
}


function oscp_save_file($onload)
{
    $oscp_options = get_option('oscp_config_data');

    // Create JSON File:
    $fileExists = file_exists(OSCP_APP_JSON_PATH);
    if ($fileExists) {
        if ($onload) {
            return;
        }
        $jsonString = file_get_contents(OSCP_APP_JSON_PATH);
        $data = json_decode($jsonString, true);
    }
    $data['acceptedResumeTypes'] = json_decode($oscp_options['oscp_resume_types']);
    $data['companyName'] = $oscp_options['oscp_company_name'];
    $data['defaultLocale'] = $oscp_options['oscp_locale'];
    $data['supportedLocales'] = explode(',', 'en-US,en-GB,en,fr-FR,fr,es,de,it,nl,ru,zh-CN');
    $data['minUploadSize'] = 4096;
    $data['languageDropdownOptions'] = array(
        'enabled' => false,
        'choices' => array(),
    );
    /** edit this to change language dropdown options **/
    $data['maxRelatedJobs'] = 5;
    $data['maxUploadSize'] = 5242880;
    $data['service']['batchSize'] = 500;
    $data['service']['corpToken'] = $oscp_options['oscp_corp_token'];
    $data['service']['port'] = null;
    $data['service']['swimlane'] = $oscp_options['oscp_swim_lane'];
    $data['service']['fields'] = explode(',', $oscp_options['oscp_fields']);
    $data['service']['jobInfoChips'] = explode(',', $oscp_options['oscp_job_info_chips']);
    $dateLastPublished = array(
        'type' => 'mediumDate',
        'field' => 'dateLastPublished',
    );
    array_push($data['service']['jobInfoChips'], $dateLastPublished);
    $data['service']['showCategory'] = true;
    $data['service']['keywordSearchFields'] = array(
        "publicDescription",
        "title"
    );

    $data['additionalJobCriteria']['field'] = $oscp_options['oscp_filter_field'];
    $data['additionalJobCriteria']['values'] = explode(',', $oscp_options['oscp_filter_values']);
    $data['additionalJobCriteria']['sort'] = is_null($oscp_options['oscp_sort']) ? '-dateLastPublished' : $oscp_options['oscp_sort'];
    $data['integrations']['googleAnalytics']['trackingId'] = $oscp_options['oscp_analytics_tracking_id'];
    $data['integrations']['googleSiteVerification']['verificationCode'] = '';
    $data['eeoc']['genderRaceEthnicity'] = ($oscp_options['oscp_gender_race_ethnicity']  === 'true');
    $data['eeoc']['veteran'] = ($oscp_options['oscp_veteran']  === 'true');
    $data['eeoc']['disability'] = ($oscp_options['oscp_disability']  === 'true');
    $data['privacyConsent']['consentCheckbox'] = ($oscp_options['oscp_consent']  === 'true');
    $data['privacyConsent']['sidebarLink'] = ($oscp_options['oscp_sidebar_link']  === 'true');
    $data['privacyConsent']['privacyPolicyUrl'] = $oscp_options['oscp_privacy_url'];
    $newJsonString = json_encode($data);
    //workaround for dealing with shared hosting file update rules
    if ($fileExists) {
        unlink(OSCP_APP_JSON_PATH);
    }
    file_put_contents(OSCP_APP_JSON_PATH, $newJsonString);
}

add_shortcode('oscp', 'oscp_plugin_add_shortcode');
